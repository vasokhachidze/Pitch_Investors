<?php $__env->startSection('app'); ?>
    <?php echo $__env->make($activeTemplate . 'partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <section class="dashbaord-section pt-80 pb-80">
        <div class="container">
            <div class="row">
                <?php if(request()->routeIs('influencer.*')): ?>
                    <?php echo $__env->make($activeTemplate . 'partials.influencer_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php else: ?>
                    <?php echo $__env->make($activeTemplate . 'partials.user_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endif; ?>

                <div class="col-xl-9">
                    <div class="dashboard-toggler-wrapper text-end radius-5 d-xl-none d-inline-block mb-4">
                        <div class="dashboard-toggler">
                            <i class="las la-align-center"></i>
                        </div>
                    </div>
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </div>
        </div>
    </section>
    <?php echo $__env->make($activeTemplate . 'partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        'use strict';
        if ($('.chat__msg-body').length) {
            function scrollHeight() {
                $('.chat__msg-body').animate({
                    scrollTop: $('.chat__msg-body')[0].scrollHeight
                });
            }
            scrollHeight();
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make($activeTemplate . 'layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fastyfvc/econofluencer.com/core/resources/views/templates/basic/layouts/master.blade.php ENDPATH**/ ?>