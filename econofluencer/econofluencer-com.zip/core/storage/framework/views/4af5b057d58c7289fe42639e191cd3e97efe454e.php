<?php echo  loadExtension('tawk-chat') ?>
<?php echo  loadExtension('google-analytics') ?><?php /**PATH /home/fastyfvc/econofluencer.com/core/resources/views/partials/plugins.blade.php ENDPATH**/ ?>