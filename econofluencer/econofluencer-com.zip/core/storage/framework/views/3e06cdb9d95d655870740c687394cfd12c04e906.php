<div class="col-xl-3">
    <div class="dash-sidebar">
        <button class="btn-close sidebar-close d-xl-none shadow-none"></button>
        <ul class="sidebar-menu">

            <li>
                <a href="<?php echo e(route('influencer.home')); ?>" class="<?php echo e(menuActive('influencer.home')); ?>"><i class="las la-home"></i> <?php echo app('translator')->get('Dashboard'); ?></a>
            </li>

            <?php
                $pendingOrders = App\Models\Order::pending()->where('influencer_id', authInfluencerId())->count();
                $pendingHires = App\Models\Hiring::pending()->where('influencer_id', authInfluencerId())->count();
            ?>

            <li class="<?php echo e(menuActive('influencer.service.*',2)); ?>">
                <a href="javascript:void(0)"><i class="las la-wallet"></i> <?php echo app('translator')->get('Service'); ?> <?php if($pendingOrders): ?> <span class="text--danger"><i class="la la-exclamation-circle" aria-hidden="true"></i></span> <?php endif; ?></a>
                <ul class="sidebar-submenu">
                    <li>
                        <a href="<?php echo e(route('influencer.service.create')); ?>" class="<?php echo e(menuActive('influencer.service.create')); ?>"><i class="la la-dot-circle"></i> <?php echo app('translator')->get('Create New'); ?></a>
                    </li>

                    <li>
                        <a href="<?php echo e(route('influencer.service.all')); ?>" class="<?php echo e(menuActive('influencer.service.all')); ?>"><i class="la la-dot-circle"></i> <?php echo app('translator')->get('All Services'); ?></a>
                    </li>

                    <li>
                        <a href="<?php echo e(route('influencer.service.order.index')); ?>" class="<?php echo e(menuActive('influencer.service.order.index')); ?>"><i class="la la-dot-circle"></i> <?php echo app('translator')->get('Orders'); ?> <?php if($pendingOrders): ?> <span class="text--danger"><i class="fas la-exclamation-circle" aria-hidden="true"></i></span><?php endif; ?></a>
                    </li>
                </ul>
            </li>
            <li>
                <a href="<?php echo e(route('influencer.hiring.index')); ?>" class="<?php echo e(menuActive('influencer.hiring*')); ?>">
                    <i class="las la-list-ol"></i> <?php echo app('translator')->get('Hirings'); ?>
                    <?php if($pendingHires): ?> <span class="text--danger"><i class="fas la-exclamation-circle" aria-hidden="true"></i></span><?php endif; ?>
                </a>
            </li>

            <li class="<?php echo e(menuActive('influencer.withdraw*',2)); ?>">
                <a href="javascript:void(0)"><i class="las la-wallet"></i> <?php echo app('translator')->get('Withdraw'); ?></a>
                <ul class="sidebar-submenu">
                    <li><a href="<?php echo e(route('influencer.withdraw')); ?>" class="<?php echo e(menuActive('influencer.withdraw')); ?>"><i class="las la-dot-circle"></i> <?php echo app('translator')->get('Withdraw Money'); ?></a></li>
                    <li><a href="<?php echo e(route('influencer.withdraw.history')); ?>" class="<?php echo e(menuActive('influencer.withdraw.history')); ?>"><i class="las la-dot-circle"></i> <?php echo app('translator')->get('Withdrawal History'); ?></a></li>
                </ul>
            </li>
            <li class="<?php echo e(menuActive('influencer.ticket.*',2)); ?>">
                <a href="javascript:void(0)"><i class="las la-ticket-alt"></i> <?php echo app('translator')->get('Support Ticket'); ?></a>
                <ul class="sidebar-submenu">
                    <li><a href="<?php echo e(route('influencer.ticket.open')); ?>" class="<?php echo e(menuActive('influencer.ticket.open')); ?>"><i class="las la-dot-circle"></i> <?php echo app('translator')->get('Open New Ticket'); ?></a></li>
                    <li><a href="<?php echo e(route('influencer.ticket')); ?>" class="<?php echo e(menuActive('influencer.ticket')); ?>"><i class="las la-dot-circle"></i> <?php echo app('translator')->get('My Tickets'); ?></a></li>
                </ul>
            </li>
            <li>
                <a href="<?php echo e(route('influencer.conversation.index', ['', ''])); ?>" class="<?php echo e(menuActive('influencer.conversation*')); ?>"><i class="las la-sms"></i> <?php echo app('translator')->get('Conversations'); ?></a>
            </li>
            <li>
                <a href="<?php echo e(route('influencer.transactions')); ?>" class="<?php echo e(menuActive('influencer.transactions')); ?>"><i class="las la-exchange-alt"></i> <?php echo app('translator')->get('Transactions'); ?></a>
            </li>
            <li>
                <a href="<?php echo e(route('influencer.profile.setting')); ?>" class="<?php echo e(menuActive('influencer.profile.setting')); ?>"><i class="las la-user-alt"></i> <?php echo app('translator')->get('Profile Setting'); ?></a>
            </li>
            <li>
                <a href="<?php echo e(route('influencer.change.password')); ?>" class="<?php echo e(menuActive('influencer.change.password')); ?>"><i class="las la-lock-open"></i> <?php echo app('translator')->get('Change Password'); ?></a>
            </li>
            <li>
                <a href="<?php echo e(route('influencer.twofactor')); ?>" class="<?php echo e(menuActive('influencer.twofactor')); ?>"><i class="las la-shield-alt"></i> <?php echo app('translator')->get('2FA Security'); ?></a>
            </li>
            <li>
                <a href="<?php echo e(route('influencer.logout')); ?>"><i class="las la-sign-in-alt"></i> <?php echo app('translator')->get('Logout'); ?></a>
            </li>
        </ul>
    </div>
</div>
<?php /**PATH /home/fastyfvc/econofluencer.com/core/resources/views/templates/basic/partials/influencer_sidebar.blade.php ENDPATH**/ ?>