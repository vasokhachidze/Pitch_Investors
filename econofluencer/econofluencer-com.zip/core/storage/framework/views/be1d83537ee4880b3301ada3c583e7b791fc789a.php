<?php
$content = getContent('category.content', true);
?>
<?php if($categories->count()): ?>
<section class="pt-80 pb-80 bg--light">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-7">
                <div class="section-header text-center">
                    <h2 class="section-header__title"><?php echo e(__($content->data_values->heading)); ?></h2>
                </div>
            </div>
        </div>

        <div class="d-flex flex-wrap cate-container justify-content-center">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('influencer.category', [$category->id, slug($category->name)])); ?>" class="d-blck cate-outer">
                <div class="category-item">
                    <div class="category-thumb">
                        <img src="<?php echo e(getImage(getFilePath('category') . '/' . $category->image, getFileSize('category'))); ?>" alt="">
                    </div>
                    <h6 class="fs--15px cate-title"><?php echo e(__($category->name)); ?></h6>
                </div>
            </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php endif; ?><?php /**PATH /home/fastyfvc/econofluencer.com/core/resources/views/templates/basic/sections/category.blade.php ENDPATH**/ ?>