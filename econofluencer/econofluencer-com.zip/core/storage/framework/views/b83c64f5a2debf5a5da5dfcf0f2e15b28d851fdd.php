<?php
$emptyMsgImage = getContent('empty_message.content', true);
?>
<?php if(request()->search): ?>
<p><?php echo app('translator')->get('Search Result For'); ?> <span class="text--base"><?php echo e(__(request()->search)); ?></span> : <?php echo app('translator')->get('Total'); ?> <span class="text--base"><?php echo e($services->count()); ?></span> <?php echo app('translator')->get('Service Found'); ?></p>
<?php endif; ?>
<?php $__empty_1 = true; $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="col-lg-4 col-xl-4 col-md-6 col-sm-10">
        <div class="service-item">
            <div class="service-item__thumb">
                <img src="<?php echo e(getImage(getFilePath('service') . '/thumb_' . $service->image, getFileThumb('service'))); ?>" alt="images">
            </div>
            <div class="service-item__content">
                <div class="influencer-thumb">
                    <img src="<?php echo e(getImage(getFilePath('influencerProfile') . '/' . @$service->influencer->image, getFileSize('influencerProfile'), true)); ?>" alt="images">
                </div>
                <div class="d-flex flex-wrap justify-content-between mb-1">
                    <h6 class="name"><i class="la la-user"></i> <?php echo e(__(@$service->influencer->username)); ?></h6>
                    <span class="service-rating">
                        <?php
                            echo showRatings(@$service->rating);
                        ?>
                        (<?php echo e(@$service->total_review ?? 0); ?>)
                    </span>
                </div>
                <h6 class="title mb-3 mt-2"><a href="<?php echo e(route('service.details', [slug($service->title), $service->id])); ?>"><?php echo e(__(@$service->title)); ?></a></h6>
                <div class="service-footer border-top pt-1 d-flex flex-wrap justify-content-between align-items-center">
                    <span class="fs--14px"><i class="fas fa-tag fs--13px me-1"></i> <?php echo e(__(@$service->category->name)); ?></span>
                    <h6 class="service-price fs--15px"><small><?php echo e($general->cur_sym); ?></small><?php echo e(showAmount($service->price)); ?></h6>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<div class="col-md-6 col-lg-8">
    <img src="<?php echo e(getImage('assets/images/frontend/empty_message/' . @$emptyMsgImage->data_values->image, '800x600')); ?>" alt="" class="w-100">
</div>
<?php endif; ?>
<?php echo e($services->links()); ?>

<?php /**PATH /home/fastyfvc/econofluencer.com/core/resources/views/templates/basic/service/filtered.blade.php ENDPATH**/ ?>