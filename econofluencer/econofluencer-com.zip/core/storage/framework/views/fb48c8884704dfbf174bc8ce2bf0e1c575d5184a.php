<?php $__env->startSection('content'); ?>
    <div class="pt-80 pb-80">
        <div class="container">
            <div class="card custom--card">
                <div class="card-header">
                    <h4 class="card-title text-start">
                        <?php echo app('translator')->get('Influencer Name'); ?> :
                        <?php echo e(__($influencer->fullname)); ?>

                    </h4>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('user.hiring.influencer', $influencer->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label class="form-label"><?php echo app('translator')->get('Title'); ?> </label>
                                    <input type="text" name="title" class="form-control form--control" value="<?php echo e(old('title')); ?>" required>
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label class="form-label"><?php echo app('translator')->get('Estimated Delivery Date'); ?> </label>
                                    <input type="text" class="datepicker-here form-control form--control" data-language='en' data-date-format="yyyy-mm-dd" data-position='bottom left' placeholder="<?php echo app('translator')->get('Select date'); ?>" name="delivery_date" autocomplete="off" required>
                                    <small class="text-small"> <i class="la la-info-circle"></i> <?php echo app('translator')->get('Year-Month-Date'); ?></small>
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label class="form-label"><?php echo app('translator')->get('Remuneration'); ?></label>
                                    <div class="input-group">
                                        <input type="number" step="any" class="form-control form--control" name="amount" value="<?php echo e(old('amount')); ?>" required>
                                        <span class="input-group-text"><?php echo e($general->cur_text); ?></span>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label class="form-label"><?php echo app('translator')->get('Payment Type'); ?></label>
                                    <select class="form-control form--control form-select" name="payment_type" required>
                                        <option value="" disabled selected><?php echo app('translator')->get('Select One'); ?></option>
                                        <option value="2"><?php echo app('translator')->get('Direct Payment'); ?></option>
                                        <option value="1"><?php echo app('translator')->get('Deposited Wallet'); ?> (<?php echo e(showAmount(auth()->user()->balance)); ?> <?php echo e($general->cur_text); ?>)</option>
                                    </select>
                                </div>
                            </div>

                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label class="form-label" for="description"><?php echo app('translator')->get('Description'); ?></label>
                                    <textarea rows="4" class="form-control form--control nicEdit" name="description" id="description" placeholder="<?php echo app('translator')->get('Description'); ?>"><?php echo e(old('description')); ?></textarea>
                                </div>
                            </div>

                            <div class="col-lg-12">
                                <button type="submit" class="btn btn--base w-100"><?php echo app('translator')->get('Submit'); ?></button>
                            </div>

                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('style-lib'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/global/css/datepicker.min.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startPush('script-lib'); ?>
    <script src="<?php echo e(asset('assets/global/js/datepicker.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/global/js/datepicker.en.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('script'); ?>
    <script>
        $('.datepicker-here').datepicker({
            changeYear: true,
            changeMonth: true,
            minDate: new Date(),
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make($activeTemplate . 'layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fastyfvc/econofluencer.com/core/resources/views/templates/basic/user/hiring/request.blade.php ENDPATH**/ ?>