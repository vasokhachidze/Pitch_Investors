<?php
if($message->order_id){
    $type = 'order';
}elseif($message->hiring_id){
    $type = 'hiring';
}else{
    $type = 'conversation';
}
?>
<li class="outgoing__msg">
    <div class="msg__item">
        <div class="post__creator">
            <div class="post__creator-content">
                <?php if($message->message): ?>
                <p><?php echo e(__($message->message)); ?></p>
                <span class="comment-date text--secondary"><?php echo e(diffForHumans($message->created_at)); ?></span>
                <?php endif; ?>
                <?php if($message->attachments): ?>
                <div>
                    <?php $__currentLoopData = json_decode($message->attachments); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $attachment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p class="m-1">
                        <a href="<?php echo e(route('attachment.download', [$attachment, $message->id, $type])); ?>" class="me-2 text-white"><i
                                class="fa fa-file text--base"></i>
                            <?php echo app('translator')->get('Attachment'); ?> <?php echo e(++$key); ?>

                        </a>
                    </p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <span class="comment-date text--secondary"><?php echo e(diffForHumans($message->created_at)); ?></span>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</li>
<?php /**PATH /home/fastyfvc/econofluencer.com/core/resources/views/templates/basic/user/conversation/last_message.blade.php ENDPATH**/ ?>