<?php
$counters = getContent('counter.element', false, null, true);
?>
<div class="counter-section bg--accent pb-40 pt-40">
    <div class="container">
        <div class="row gy-3">
            <?php $__currentLoopData = $counters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $counter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-6 col-sm-6 col-xl-3">
                    <div class="counter__item">
                        <div class="inner">
                            <div class="counter__item-icon">
                                <?php
                                    echo @$counter->data_values->counter_icon;
                                ?>
                            </div>
                            <div class="counter__item-content">
                                <h3 class="counter__item-title text-white"><?php echo e(@$counter->data_values->counter_digit); ?></h3>
                                <span class="info"><?php echo e(__(@$counter->data_values->title)); ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php /**PATH /home/fastyfvc/econofluencer.com/core/resources/views/templates/basic/sections/counter.blade.php ENDPATH**/ ?>