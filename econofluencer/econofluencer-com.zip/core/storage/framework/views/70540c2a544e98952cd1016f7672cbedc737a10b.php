<!DOCTYPE html>
<html>
<head>
    <title>Welcome Email</title>
</head>

<body>
<h2>Welcome to the Econofluencer <?php echo e($user['username']); ?></h2>
<br/>
Your registered email-id is <?php echo e($user['email']); ?>

</body>

</html><?php /**PATH /home/fastyfvc/econofluencer.com/core/resources/views/emails/welcome.blade.php ENDPATH**/ ?>