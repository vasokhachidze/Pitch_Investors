
<?php $__env->startSection('panel'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card b-radius--10 ">
                <div class="card-body p-0">
                    <div class="table-responsive--md  table-responsive">
                        <table class="table table--light style--two">
                            <thead>
                                <tr>
                                    <th><?php echo app('translator')->get('Name'); ?></th>
                                    <th><?php echo app('translator')->get('Action'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>

                                    <td data-label="<?php echo app('translator')->get('Name'); ?>">
                                        <span class="fw-bold"><?php echo e(__($tag->name)); ?></span>
                                    </td>

                                    <td data-label="<?php echo app('translator')->get('Action'); ?>">
                                        <button class="btn btn-sm btn-outline--primary editButton" data-id="<?php echo e($tag->id); ?>" data-name="<?php echo e($tag->name); ?>">
                                            <i class="las la-edit text--shadow"></i> <?php echo app('translator')->get('Edit'); ?>
                                        </button>
                                        <button class="btn btn-sm btn-outline--danger confirmationBtn" data-action="<?php echo e(route('admin.tag.delete',$tag->id)); ?>" data-question="<?php echo app('translator')->get('Are you sure to delete this tag?'); ?>" data-btn_class="btn btn--primary">
                                            <i class="las la-edit text--shadow"></i> <?php echo app('translator')->get('Delete'); ?>
                                        </button>
                                    </td>

                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td class="text-muted text-center" colspan="100%"><?php echo e(__($emptyMessage)); ?></td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <?php if($tags->hasPages()): ?>
                <div class="card-footer py-4">
                    <?php echo e(paginateLinks($tags)); ?>

                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="modal fade" id="tagModal" tabindex="-1" role="dialog" aria-labelledby="createModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="createModalLabel"><?php echo app('translator')->get('Update Tag Name'); ?></h4>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close"><i class="las la-times"></i></button>
                </div>
                <form class="form-horizontal" method="post" action="">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="form-group">
                            <label><?php echo app('translator')->get('Name'); ?></label>
                            <div class="col-sm-12">
                                <input type="text" class="form-control" value="<?php echo e(old('name')); ?>" name="name" required>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn--primary w-100 h-45" id="btn-save" value="add"><?php echo app('translator')->get('Submit'); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <?php if (isset($component)) { $__componentOriginalc51724be1d1b72c3a09523edef6afdd790effb8b = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\ConfirmationModal::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('confirmation-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\ConfirmationModal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc51724be1d1b72c3a09523edef6afdd790effb8b)): ?>
<?php $component = $__componentOriginalc51724be1d1b72c3a09523edef6afdd790effb8b; ?>
<?php unset($__componentOriginalc51724be1d1b72c3a09523edef6afdd790effb8b); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('breadcrumb-plugins'); ?>
    <div class="d-flex flex-colum flex-wrap gap-2 justify-content-end align-items-center">
        <button class="btn btn-lg btn-outline--primary createButton"><i class="las la-plus"></i><?php echo app('translator')->get('Add New'); ?></button>
        <form action="" method="GET" class="form-inline">
            <div class="input-group justify-content-end">
                <input type="text" name="search" class="form-control bg--white" placeholder="<?php echo app('translator')->get('Search here'); ?>" value="<?php echo e(request()->search); ?>">
                <button class="btn btn--primary input-group-text" type="submit"><i class="fa fa-search"></i></button>
            </div>
        </form>
    </div>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
<script>
    (function($) {
            "use strict"

            $('.createButton').on('click', function() {
                var modal = $('#tagModal');
                modal.find('form').attr('action', `<?php echo e(route('admin.tag.add')); ?>`);
                modal.find('[name=name]').val($(this).data('name'));
                modal.modal('show')
            });

            $('.editButton').on('click', function() {
                var modal = $('#tagModal');
                modal.find('form').attr('action', `<?php echo e(route('admin.tag.add','')); ?>/${$(this).data('id')}`);
                modal.find('[name=name]').val($(this).data('name'));
                modal.modal('show')
            });

        })(jQuery);
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fastyfvc/econofluencer.com/core/resources/views/admin/tags/index.blade.php ENDPATH**/ ?>