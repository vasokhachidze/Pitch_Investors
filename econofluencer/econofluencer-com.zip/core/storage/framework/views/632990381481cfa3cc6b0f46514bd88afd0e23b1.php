<?php
$aboutUs = getContent('about.content', true);
?>
<section class="about-section pt-80 pb-80">
    <div class="container">
        <div class="row gy-4 gy-sm-5">
            <div class="col-lg-5">
                <div class="section-header mb-0">
                    <h2 class="section-header__title"><?php echo e(__(@$aboutUs->data_values->title)); ?></h2>
                    <p><?php echo e(__(@$aboutUs->data_values->short_detail)); ?></p>
                    <a href="<?php echo e(@$aboutUs->data_values->button_url); ?>" class="cmn--btn"><?php echo e(__(@$aboutUs->data_values->button_name)); ?></a>
                </div>
            </div>
            <div class="col-lg-7">
                <div class="section-thumb about-thumb pb-lg-5 mb-lg-4">
                    <img src="<?php echo e(getImage('assets/images/frontend/about/' . @$aboutUs->data_values->image, '600x400')); ?>" alt="thumb">
                    <div class="thumb-content">
                        <span class="fw-bold mb-3 text-uppercase text-white"><?php echo e(__(@$aboutUs->data_values->heading)); ?></span>
                        <h4 class="tilte mb-2 text-white"><?php echo e(__(@$aboutUs->data_values->subheading)); ?></h4>
                        <p class="text-white"><?php echo e(__(@$aboutUs->data_values->description)); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php /**PATH /home/fastyfvc/econofluencer.com/core/resources/views/templates/basic/sections/about.blade.php ENDPATH**/ ?>