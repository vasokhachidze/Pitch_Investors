<?php $__env->startSection('content'); ?>
    <div class="card custom--card">
        <div class="card-header">
            <h5 class="card-title"><?php echo app('translator')->get('Withdraw Via'); ?> <?php echo e($withdraw->method->name); ?></h5>
        </div>
        <div class="card-body">
            <form action="<?php echo e(route('influencer.withdraw.submit')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="mb-2">
                    <?php
                        echo $withdraw->method->description;
                    ?>
                </div>
                <div class="row">
                    <?php if (isset($component)) { $__componentOriginale40beaa5cbfa24869bd0b7ba4d9f41184a3f12f0 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\ViserForm::class, ['identifier' => 'id','identifierValue' => ''.e($withdraw->method->form_id).''] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('viser-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\ViserForm::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale40beaa5cbfa24869bd0b7ba4d9f41184a3f12f0)): ?>
<?php $component = $__componentOriginale40beaa5cbfa24869bd0b7ba4d9f41184a3f12f0; ?>
<?php unset($__componentOriginale40beaa5cbfa24869bd0b7ba4d9f41184a3f12f0); ?>
<?php endif; ?>
                </div>
                <?php if(authInfluencer()->ts): ?>
                    <div class="form-group">
                        <label class="col-form-label"><?php echo app('translator')->get('Google Authenticator Code'); ?></label>
                        <input type="text" name="authenticator_code" class="form-control form--control" required>
                    </div>
                <?php endif; ?>
                <div class="form-group">
                    <button type="submit" class="btn btn--base w-100 mt-3"><?php echo app('translator')->get('Submit'); ?></button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make($activeTemplate . 'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fastyfvc/econofluencer.com/core/resources/views/templates/basic/influencer/withdraw/preview.blade.php ENDPATH**/ ?>