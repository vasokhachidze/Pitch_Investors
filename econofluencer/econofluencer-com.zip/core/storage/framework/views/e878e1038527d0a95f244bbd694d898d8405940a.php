<div class="col-xl-3">
    <div class="dash-sidebar">
        <button class="btn-close sidebar-close d-xl-none shadow-none"></button>
        <ul class="sidebar-menu">

            <li>
                <a href="<?php echo e(route('user.home')); ?>" class="<?php echo e(menuActive('user.home')); ?>"><i class="las la-home"></i> <?php echo app('translator')->get('Dashboard'); ?></a>
            </li>

            <li class="<?php echo e(menuActive('user.deposit*',2)); ?>">
                <a href="javascript:void(0)"><i class="las la-wallet"></i> <?php echo app('translator')->get('Deposit'); ?></a>

                <ul class="sidebar-submenu  }}">
                    <li><a href="<?php echo e(route('user.deposit')); ?>" class="<?php echo e(menuActive('user.deposit')); ?>"><i class="las la-dot-circle"></i> <?php echo app('translator')->get('Deposit Money'); ?></a></li>
                    <li><a href="<?php echo e(route('user.deposit.history')); ?>" class="<?php echo e(menuActive('user.deposit.history')); ?>"><i class="las la-dot-circle"></i> <?php echo app('translator')->get('Deposit History'); ?></a></li>
                </ul>
            </li>

            <li>
                <a href="<?php echo e(route('user.order.all')); ?>" class="<?php echo e(menuActive('user.order.*')); ?>"><i class="las la-list"></i> <?php echo app('translator')->get('Orders'); ?></a>
            </li>

            <li>
                <a href="<?php echo e(route('user.hiring.history')); ?>" class="<?php echo e(menuActive('user.hiring.*')); ?>"> <i class="las la-list-ol"></i> <?php echo app('translator')->get('Hirings'); ?></a>
            </li>

            <li class="<?php echo e(menuActive('ticket*',2)); ?>">
                <a href="javascript:void(0)"><i class="las la-ticket-alt"></i> <?php echo app('translator')->get('Support Ticket'); ?></a>
                <ul class="sidebar-submenu <?php echo e(menuActive('ticket*')); ?>">
                    <li><a href="<?php echo e(route('ticket.open')); ?>" class="<?php echo e(menuActive('ticket.open')); ?>"><i class="las la-dot-circle"></i> <?php echo app('translator')->get('Open New Ticket'); ?></a></li>
                    <li><a href="<?php echo e(route('ticket')); ?>" class="<?php echo e(menuActive('ticket')); ?>"><i class="las la-dot-circle"></i> <?php echo app('translator')->get('My Tickets'); ?></a></li>
                </ul>
            </li>

            <li>
                <a href="<?php echo e(route('user.conversation.index', ['', ''])); ?>" class="<?php echo e(menuActive('user.conversation.*')); ?>"><i class="las la-sms"></i> <?php echo app('translator')->get('Conversations'); ?></a>
            </li>

            <li>
                <a href="<?php echo e(route('user.favorite.list')); ?>" class="<?php echo e(menuActive('user.favorite.list')); ?>"><i class="lar la-heart"></i> <?php echo app('translator')->get('Favorite List'); ?></a>
            </li>

            <li class="<?php echo e(menuActive('user.review*',2)); ?>">
                <a href="javascript:void(0)"><i class="la la-star-o"></i> <?php echo app('translator')->get('Reviews'); ?></a>
                <ul class="sidebar-submenu">
                    <li>
                        <a href="<?php echo e(route('user.review.order.index')); ?>" class="<?php echo e(menuActive('user.review.order.index')); ?>">
                            <i class="las la-dot-circle"></i> <?php echo app('translator')->get('Order Reviews'); ?>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('user.review.hiring.index')); ?>" class="<?php echo e(menuActive('user.review.hiring.index')); ?>">
                            <i class="las la-dot-circle"></i> <?php echo app('translator')->get('Hiring Reviews'); ?>
                        </a>
                    </li>
                </ul>
            </li>

            <li>
                <a href="<?php echo e(route('user.transactions')); ?>" class="<?php echo e(menuActive('user.transactions')); ?>"><i class="las la-exchange-alt"></i> <?php echo app('translator')->get('Transactions'); ?></a>
            </li>

            <li>
                <a href="<?php echo e(route('user.profile.setting')); ?>" class="<?php echo e(menuActive('user.profile.setting')); ?>"><i class="las la-user-alt"></i> <?php echo app('translator')->get('Profile Setting'); ?></a>
            </li>

            <li>
                <a href="<?php echo e(route('user.change.password')); ?>" class="<?php echo e(menuActive('user.change.password')); ?>"><i class="las la-lock-open"></i> <?php echo app('translator')->get('Change Password'); ?></a>
            </li>

            <li>
                <a href="<?php echo e(route('user.twofactor')); ?>" class="<?php echo e(menuActive('user.twofactor')); ?>"><i class="las la-shield-alt"></i> <?php echo app('translator')->get('2FA Security'); ?></a>
            </li>

            <li>
                <a href="<?php echo e(route('user.logout')); ?>"><i class="las la-sign-in-alt"></i> <?php echo app('translator')->get('Logout'); ?></a>
            </li>
        </ul>
    </div>
</div>
<?php /**PATH /home/fastyfvc/econofluencer.com/core/resources/views/templates/basic/partials/user_sidebar.blade.php ENDPATH**/ ?>