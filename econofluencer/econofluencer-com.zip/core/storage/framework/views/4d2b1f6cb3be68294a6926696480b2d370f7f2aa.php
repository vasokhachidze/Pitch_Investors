<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <form action="" class="d-flex flex-wrap justify-content-end ms-auto table--form mb-3">
                <div class="input-group">
                    <input type="text" name="search" class="form-control form--control" value="<?php echo e(request()->search); ?>"
                        placeholder="<?php echo app('translator')->get('Search by name'); ?>">
                    <button class="input-group-text bg--base text-white border-0 px-4"><i class="las la-search"></i></button>
                </div>
            </form>
            <table class="table table--responsive--lg">
                <thead>
                    <tr>
                        <th><?php echo app('translator')->get('Client'); ?></th>
                        <th><?php echo app('translator')->get('Message'); ?></th>
                        <th><?php echo app('translator')->get('Last Sent'); ?></th>
                        <th><?php echo app('translator')->get('Action'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $conversations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $conversation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td data-label="<?php echo app('translator')->get('Client'); ?>">
                                <div>
                                    <span class="fw-bold"><?php echo e(__(@$conversation->user->fullname)); ?></span>
                                    <br>
                                    <small> <?php echo e(__(@$conversation->user->username)); ?> </small>
                                </div>
                            </td>

                            <td data-label="<?php echo app('translator')->get('Message'); ?>">
                                <span><?php echo e(strLimit(@$conversation->lastMessage->message,30)); ?></span>
                            </td>

                            <td data-label="<?php echo app('translator')->get('Last Sent'); ?>">
                                <?php echo e(showDateTime(@$conversation->lastMessage->created_at)); ?><br><?php echo e(diffForHumans(@$conversation->lastMessage->created_at)); ?>

                            </td>

                            <td data-label="<?php echo app('translator')->get('Action'); ?>">
                                <a href="<?php echo e(route('influencer.conversation.view',$conversation->id)); ?>" class="btn btn--sm btn--outline-base">
                                    <i class="las la-sms"></i> <?php echo app('translator')->get('Chat'); ?>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td class="justify-content-center text-center" colspan="100%">
                                <i class="la la-4x la-frown"></i>
                                <br>
                                <?php echo app('translator')->get('No messages yet'); ?>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php if($conversations): ?>
        <?php echo e($conversations->links()); ?>

        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($activeTemplate . 'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fastyfvc/econofluencer.com/core/resources/views/templates/basic/influencer/conversation/index.blade.php ENDPATH**/ ?>