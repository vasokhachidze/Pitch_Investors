<?php $__currentLoopData = $conversationMessage->reverse(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $conversation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php
if($conversation->order_id){
    $type = 'order';
}elseif($conversation->hiring_id){
    $type = 'hiring';
}else{
    $type = 'conversation';
}
?>
<?php if($conversation->sender == 'client'): ?>
<li class="outgoing__msg">
    <div class="msg__item">
        <div class="post__creator">
            <div class="post__creator-content">
                <?php if($conversation->message): ?>
                <p><?php echo e(__($conversation->message)); ?></p>
                <span class="comment-date text--secondary"><?php echo e(diffForHumans($conversation->created_at)); ?></span>
                <?php endif; ?>
                <?php if($conversation->attachments): ?>
                <div>
                    <?php $__currentLoopData = json_decode($conversation->attachments); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $attachment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p class="m-1">
                        <a href="<?php echo e(route('attachment.download', [$attachment, $conversation->id, $type])); ?>" class="me-2 text-white"><i
                                class="fa fa-file text--base"></i>
                            <?php echo app('translator')->get('Attachment'); ?> <?php echo e(++$key); ?>

                        </a>
                    </p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <span class="comment-date text--secondary"><?php echo e(diffForHumans($conversation->created_at)); ?></span>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</li>
<?php else: ?>
<li class="incoming__msg">
    <div class="msg__item">
        <div class="post__creator">
            <div class="post__creator-content">
                <?php if($conversation->message): ?>
                <?php if($conversation->sender == 'admin'): ?>
                    <p class="admin_message"><?php echo e(__($conversation->message)); ?></p>
                    <span class="comment-date text--danger"> <?php echo app('translator')->get('Admin'); ?> </span>
                <?php else: ?>
                <p><?php echo e(__($conversation->message)); ?></p>
                <?php endif; ?>
                <span class="comment-date text--secondary"><?php echo e(diffForHumans($conversation->created_at)); ?></span>
                <?php endif; ?>
                <?php if($conversation->attachments): ?>
                <div>
                    <?php $__currentLoopData = json_decode($conversation->attachments); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $attachment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p class="m-1">
                        <a href="<?php echo e(route('attachment.download', [$attachment, $conversation->id, $type])); ?>" class="me-2 text--base"><i
                                class="fa fa-file text--base"></i>
                            <?php echo app('translator')->get('Attachment'); ?> <?php echo e(++$key); ?>

                        </a>
                    </p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <span class="comment-date text--secondary"><?php echo e(diffForHumans($conversation->created_at)); ?></span>

                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</li>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH /home/fastyfvc/econofluencer.com/core/resources/views/templates/basic/user/conversation/message.blade.php ENDPATH**/ ?>